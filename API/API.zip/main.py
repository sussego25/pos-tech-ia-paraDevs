from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Query
from typing import List
import pickle

@asynccontextmanager
async def lifespan(app: FastAPI):
    global model
    with open("model.pkl", "rb") as f:
        model = pickle.load(f)
    yield

app = FastAPI(lifespan=lifespan)

@app.get("/health")
def health():
    return "Healthy"

@app.get("/predict")
def predict(
    features: List[int] = Query(
        ..., 
        description="Valores das features para a predição. Ex: ?features=1.2&features=3.4"
    )
):
    try:
        pred = model.predict([features])
        return {"prediction": bool(pred[0])}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))