"""
# ANÁLISE EXPLORATÓRIA E MACHINE LEARNING PARA DETECÇÃO DE DENGUE
# ==============================================================
# Autor: Manus AI
# Data: Julho 2025
# Descrição: Pipeline completo para análise exploratória e machine learning
#            para identificação de casos de dengue a partir de dados clínicos.

# Este notebook integra todas as etapas do processo de análise de dados e machine learning:
# 1. Carregamento e exploração inicial dos dados
# 2. Limpeza e tratamento de valores ausentes
# 3. Visualização exploratória dos dados
# 4. Feature engineering e pré-processamento
# 5. Seleção de features relevantes
# 6. Treino e teste de modelos de machine learning
# 7. Avaliação e comparação de acurácia dos modelos

# INSTRUÇÕES DE USO:
# -----------------
# 1. Faça upload dos arquivos DENGBR25_teste.csv e dic_dados_dengue.pdf para o Google Colab
# 2. Execute cada célula sequencialmente
# 3. Analise os resultados e visualizações geradas
# 4. Adapte o código conforme necessário para seu caso específico
"""

# Configuração inicial do ambiente
#--------------------------------
# Importando as bibliotecas necessárias
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif, RFE
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix, 
                            roc_curve, auc, precision_recall_curve)
import time
import warnings
warnings.filterwarnings('ignore')

# Configurações para visualização
plt.style.use('seaborn-v0_8-whitegrid')
sns.set(font_scale=1.2)
pd.set_option('display.max_columns', None)

# No Google Colab, você pode fazer upload dos arquivos assim:
# from google.colab import files
# uploaded = files.upload()  # Faça upload do arquivo DENGBR25_teste.csv

# 1. CARREGAMENTO E EXPLORAÇÃO INICIAL DOS DADOS
#-----------------------------------------------
print("\n" + "="*80)
print("1. CARREGAMENTO E EXPLORAÇÃO INICIAL DOS DADOS")
print("="*80)

# Carregando o dataset
print("Carregando o dataset de dengue...")
df = pd.read_csv('DENGBR25_teste.csv')

# Visualizando as primeiras linhas do dataset
print("\n--- Primeiras 5 linhas do dataset ---")
print(df.head())

# Informações gerais sobre o dataset
print("\n--- Informações gerais do dataset ---")
print(df.info())

# Estatísticas descritivas das colunas numéricas
print("\n--- Estatísticas descritivas ---")
print(df.describe())

# Verificando a quantidade de valores ausentes por coluna
print("\n--- Valores ausentes por coluna ---")
missing_values = df.isnull().sum()
missing_percent = (df.isnull().sum() / len(df)) * 100
missing_data = pd.concat([missing_values, missing_percent], axis=1)
missing_data.columns = ['Valores Ausentes', 'Porcentagem (%)']
print(missing_data[missing_data['Valores Ausentes'] > 0].sort_values('Porcentagem (%)', ascending=False))

# Verificando a quantidade de valores ausentes por linha
print("\n--- Distribuição de valores ausentes por linha ---")
missing_rows = df.isnull().sum(axis=1)
print(f"Média de valores ausentes por linha: {missing_rows.mean():.2f}")
print(f"Máximo de valores ausentes em uma linha: {missing_rows.max()}")
print(f"Número de linhas com mais de 30% de valores ausentes: {sum(missing_rows > 0.3 * df.shape[1])}")

# Verificando a distribuição da variável alvo (assumindo que CLASSI_FIN é a variável alvo para dengue)
print("\n--- Distribuição da variável alvo (CLASSI_FIN) ---")
if 'CLASSI_FIN' in df.columns:
    print(df['CLASSI_FIN'].value_counts())
    print(f"Porcentagem de cada classe:\n{df['CLASSI_FIN'].value_counts(normalize=True) * 100}")
else:
    print("Coluna CLASSI_FIN não encontrada. Verifique o nome correto da variável alvo.")

# Verificando a distribuição de alguns sintomas importantes
print("\n--- Distribuição de sintomas importantes ---")
sintomas = ['FEBRE', 'MIALGIA', 'CEFALEIA', 'EXANTEMA', 'VOMITO', 'NAUSEA']
for sintoma in sintomas:
    if sintoma in df.columns:
        print(f"\nDistribuição de {sintoma}:")
        print(df[sintoma].value_counts())
    else:
        print(f"Coluna {sintoma} não encontrada.")

# 2. LIMPEZA DE DADOS E TRATAMENTO DE VALORES AUSENTES
#----------------------------------------------------
print("\n" + "="*80)
print("2. LIMPEZA DE DADOS E TRATAMENTO DE VALORES AUSENTES")
print("="*80)

print("Iniciando o processo de limpeza de dados...")

# 2.1 Removendo linhas com muitos valores ausentes
#-------------------------------------------------
# Definimos um limite de tolerância para valores ausentes (ex: 30%)
limite_ausentes = 0.3

# Calculando a proporção de valores ausentes por linha
prop_ausentes_por_linha = df.isnull().sum(axis=1) / df.shape[1]

# Filtrando o dataframe para manter apenas linhas com menos valores ausentes que o limite
print(f"Número de linhas antes da remoção: {df.shape[0]}")
df_limpo = df[prop_ausentes_por_linha <= limite_ausentes]
print(f"Número de linhas após remover aquelas com mais de {limite_ausentes*100}% de valores ausentes: {df_limpo.shape[0]}")
print(f"Foram removidas {df.shape[0] - df_limpo.shape[0]} linhas.")

# 2.2 Tratando valores ausentes nas colunas restantes
#---------------------------------------------------
# Vamos identificar colunas com valores ausentes após a remoção das linhas
missing_values = df_limpo.isnull().sum()
missing_percent = (df_limpo.isnull().sum() / len(df_limpo)) * 100
missing_data = pd.concat([missing_values, missing_percent], axis=1)
missing_data.columns = ['Valores Ausentes', 'Porcentagem (%)']
colunas_com_ausentes = missing_data[missing_data['Valores Ausentes'] > 0].sort_values('Porcentagem (%)', ascending=False)

print("\n--- Colunas com valores ausentes após remoção de linhas ---")
print(colunas_com_ausentes)

# Separando colunas numéricas e categóricas para tratamento diferenciado
colunas_numericas = df_limpo.select_dtypes(include=['int64', 'float64']).columns
colunas_categoricas = df_limpo.select_dtypes(include=['object']).columns

print(f"\nColunas numéricas: {len(colunas_numericas)}")
print(f"Colunas categóricas: {len(colunas_categoricas)}")

# 2.3 Tratando valores ausentes em colunas numéricas
#--------------------------------------------------
# Para colunas numéricas, vamos preencher com a mediana (menos sensível a outliers que a média)
for coluna in colunas_numericas:
    if df_limpo[coluna].isnull().sum() > 0:
        mediana = df_limpo[coluna].median()
        df_limpo[coluna] = df_limpo[coluna].fillna(mediana)
        print(f"Coluna {coluna}: {df_limpo[coluna].isnull().sum()} valores ausentes preenchidos com a mediana ({mediana})")

# 2.4 Tratando valores ausentes em colunas categóricas
#----------------------------------------------------
# Para colunas categóricas, vamos preencher com o valor mais frequente (moda)
for coluna in colunas_categoricas:
    if df_limpo[coluna].isnull().sum() > 0:
        moda = df_limpo[coluna].mode()[0]
        df_limpo[coluna] = df_limpo[coluna].fillna(moda)
        print(f"Coluna {coluna}: {df_limpo[coluna].isnull().sum()} valores ausentes preenchidos com a moda ({moda})")

# 2.5 Verificando se ainda existem valores ausentes
#-------------------------------------------------
valores_ausentes_restantes = df_limpo.isnull().sum().sum()
print(f"\nValores ausentes restantes no dataset: {valores_ausentes_restantes}")

# 2.6 Tratando inconsistências nos dados
#--------------------------------------
# Verificando valores únicos em colunas importantes para identificar possíveis inconsistências

# Exemplo para a coluna de classificação final (se existir)
if 'CLASSI_FIN' in df_limpo.columns:
    print("\nValores únicos na coluna CLASSI_FIN:")
    print(df_limpo['CLASSI_FIN'].value_counts())
    
    # Verificando se há valores inválidos ou inconsistentes
    # Valores esperados: 10 (Dengue), 11 (Dengue com sinais de alarme), 12 (Dengue grave)
    valores_validos = [10, 11, 12]
    valores_invalidos = df_limpo[~df_limpo['CLASSI_FIN'].isin(valores_validos)]
    
    if len(valores_invalidos) > 0:
        print(f"\nEncontrados {len(valores_invalidos)} registros com valores inválidos em CLASSI_FIN.")
        # Opção 1: Remover registros com valores inválidos
        # df_limpo = df_limpo[df_limpo['CLASSI_FIN'].isin(valores_validos)]
        
        # Opção 2: Substituir valores inválidos pelo valor mais comum
        valor_mais_comum = df_limpo['CLASSI_FIN'].mode()[0]
        df_limpo.loc[~df_limpo['CLASSI_FIN'].isin(valores_validos), 'CLASSI_FIN'] = valor_mais_comum
        print(f"Valores inválidos substituídos pelo valor mais comum: {valor_mais_comum}")

# 2.7 Verificando e removendo duplicatas
#--------------------------------------
duplicatas = df_limpo.duplicated().sum()
print(f"\nNúmero de linhas duplicadas: {duplicatas}")

if duplicatas > 0:
    df_limpo = df_limpo.drop_duplicates()
    print(f"Duplicatas removidas. Novo tamanho do dataset: {df_limpo.shape[0]}")

# 2.8 Convertendo tipos de dados (se necessário)
#----------------------------------------------
# Exemplo: converter colunas de data para o tipo datetime
colunas_data = [col for col in df_limpo.columns if col.startswith('DT_')]
for coluna in colunas_data:
    try:
        df_limpo[coluna] = pd.to_datetime(df_limpo[coluna], errors='coerce')
        print(f"Coluna {coluna} convertida para datetime.")
    except:
        print(f"Não foi possível converter a coluna {coluna} para datetime.")

# 2.9 Resumo final após limpeza
#-----------------------------
print("\n--- Resumo do dataset após limpeza ---")
print(f"Dimensões do dataset limpo: {df_limpo.shape}")
print(f"Memória utilizada: {df_limpo.memory_usage().sum() / 1024**2:.2f} MB")

# 3. VISUALIZAÇÃO EXPLORATÓRIA DOS DADOS
#---------------------------------------
print("\n" + "="*80)
print("3. VISUALIZAÇÃO EXPLORATÓRIA DOS DADOS")
print("="*80)

print("Iniciando visualização exploratória dos dados...")

# 3.1 Histogramas para variáveis numéricas
#----------------------------------------
print("\n--- Criando histogramas para variáveis numéricas ---")

# Selecionando algumas colunas numéricas relevantes para visualização
# Ajuste estas colunas conforme necessário para seu dataset
colunas_numericas_viz = [col for col in df_limpo.select_dtypes(include=['int64', 'float64']).columns 
                        if col not in ['TP_NOT', 'SEM_NOT', 'NU_ANO']][:10]  # Limitando a 10 colunas para não sobrecarregar

# Criando histogramas
plt.figure(figsize=(15, 10))
for i, coluna in enumerate(colunas_numericas_viz, 1):
    plt.subplot(3, 4, i)
    sns.histplot(df_limpo[coluna], kde=True)
    plt.title(f'Distribuição de {coluna}')
    plt.tight_layout()
plt.suptitle('Histogramas de Variáveis Numéricas', fontsize=16)
plt.subplots_adjust(top=0.9)
plt.show()

# 3.2 Gráficos de barras para variáveis categóricas
#-------------------------------------------------
print("\n--- Criando gráficos de barras para variáveis categóricas ---")

# Selecionando algumas colunas categóricas relevantes
# Ajuste estas colunas conforme necessário para seu dataset
colunas_categoricas_viz = ['CS_SEXO', 'CS_GESTANT', 'CS_RACA', 'FEBRE', 'MIALGIA', 'CEFALEIA', 'EXANTEMA', 'VOMITO', 'NAUSEA']
colunas_categoricas_viz = [col for col in colunas_categoricas_viz if col in df_limpo.columns][:9]  # Limitando a 9 colunas

# Criando gráficos de barras
plt.figure(figsize=(15, 10))
for i, coluna in enumerate(colunas_categoricas_viz, 1):
    plt.subplot(3, 3, i)
    sns.countplot(y=df_limpo[coluna])
    plt.title(f'Contagem de {coluna}')
    plt.tight_layout()
plt.suptitle('Distribuição de Variáveis Categóricas', fontsize=16)
plt.subplots_adjust(top=0.9)
plt.show()

# 3.3 Boxplots para identificar outliers em variáveis numéricas
#-------------------------------------------------------------
print("\n--- Criando boxplots para identificar outliers ---")

plt.figure(figsize=(15, 10))
for i, coluna in enumerate(colunas_numericas_viz, 1):
    plt.subplot(3, 4, i)
    sns.boxplot(y=df_limpo[coluna])
    plt.title(f'Boxplot de {coluna}')
    plt.tight_layout()
plt.suptitle('Boxplots para Identificação de Outliers', fontsize=16)
plt.subplots_adjust(top=0.9)
plt.show()

# 3.4 Gráficos de dispersão (scatter plots) para relações entre variáveis
#-----------------------------------------------------------------------
print("\n--- Criando gráficos de dispersão para analisar relações entre variáveis ---")

# Verificando se temos a variável alvo para colorir os pontos
target_column = 'CLASSI_FIN' if 'CLASSI_FIN' in df_limpo.columns else None

# Selecionando algumas combinações de variáveis numéricas para scatter plots
# Limitando a algumas combinações para não sobrecarregar
pares_variaveis = [
    ('NU_IDADE_N', 'FEBRE'),
    ('NU_IDADE_N', 'MIALGIA'),
    ('FEBRE', 'MIALGIA'),
    ('CEFALEIA', 'EXANTEMA')
]

# Criando scatter plots
plt.figure(figsize=(15, 10))
for i, (x, y) in enumerate(pares_variaveis, 1):
    if x in df_limpo.columns and y in df_limpo.columns:
        plt.subplot(2, 2, i)
        if target_column:
            sns.scatterplot(x=df_limpo[x], y=df_limpo[y], hue=df_limpo[target_column])
            plt.title(f'Relação entre {x} e {y} por {target_column}')
        else:
            sns.scatterplot(x=df_limpo[x], y=df_limpo[y])
            plt.title(f'Relação entre {x} e {y}')
        plt.tight_layout()
plt.suptitle('Gráficos de Dispersão', fontsize=16)
plt.subplots_adjust(top=0.9)
plt.show()

# 3.5 Mapa de calor de correlação
#-------------------------------
print("\n--- Criando mapa de calor de correlação ---")

# Selecionando apenas colunas numéricas para o mapa de correlação
# Limitando a um número razoável de colunas para melhor visualização
colunas_correlacao = df_limpo.select_dtypes(include=['int64', 'float64']).columns[:15]

# Calculando a matriz de correlação
matriz_correlacao = df_limpo[colunas_correlacao].corr()

# Criando o mapa de calor
plt.figure(figsize=(14, 12))
sns.heatmap(matriz_correlacao, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title('Mapa de Calor de Correlação entre Variáveis Numéricas', fontsize=16)
plt.xticks(rotation=45, ha='right')
plt.yticks(rotation=0)
plt.tight_layout()
plt.show()

# 3.6 Visualização da distribuição da variável alvo
#-------------------------------------------------
if target_column:
    print(f"\n--- Visualizando a distribuição da variável alvo ({target_column}) ---")
    
    plt.figure(figsize=(10, 6))
    sns.countplot(x=df_limpo[target_column])
    plt.title(f'Distribuição da Variável Alvo: {target_column}')
    plt.xlabel(target_column)
    plt.ylabel('Contagem')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
    
    # Calculando a proporção de cada classe
    proporcao = df_limpo[target_column].value_counts(normalize=True) * 100
    print("\nProporção de cada classe:")
    for classe, prop in proporcao.items():
        print(f"Classe {classe}: {prop:.2f}%")

# 3.7 Análise de sintomas por classificação (se aplicável)
#--------------------------------------------------------
if target_column and all(col in df_limpo.columns for col in ['FEBRE', 'MIALGIA', 'CEFALEIA']):
    print("\n--- Analisando sintomas por classificação ---")
    
    sintomas = ['FEBRE', 'MIALGIA', 'CEFALEIA', 'EXANTEMA', 'VOMITO', 'NAUSEA']
    sintomas = [s for s in sintomas if s in df_limpo.columns]
    
    plt.figure(figsize=(15, 10))
    for i, sintoma in enumerate(sintomas, 1):
        plt.subplot(2, 3, i)
        sns.countplot(x=target_column, hue=df_limpo[sintoma])
        plt.title(f'{sintoma} por {target_column}')
        plt.xlabel(target_column)
        plt.ylabel('Contagem')
        plt.legend(title=sintoma)
        plt.tight_layout()
    plt.suptitle('Presença de Sintomas por Classificação', fontsize=16)
    plt.subplots_adjust(top=0.9)
    plt.show()

print("\nVisualização exploratória dos dados concluída!")

# 4. FEATURE ENGINEERING E PRÉ-PROCESSAMENTO
#-------------------------------------------
print("\n" + "="*80)
print("4. FEATURE ENGINEERING E PRÉ-PROCESSAMENTO")
print("="*80)

print("Iniciando feature engineering e pré-processamento dos dados...")

# 4.1 Definindo a variável alvo (target)
#--------------------------------------
# Assumindo que CLASSI_FIN é nossa variável alvo para identificar se tem ou não dengue
# Valores: 10 (Dengue), 11 (Dengue com sinais de alarme), 12 (Dengue grave)

target_column = 'CLASSI_FIN'

if target_column in df_limpo.columns:
    print(f"\nUsando {target_column} como variável alvo")
    
    # Verificando a distribuição da variável alvo
    print(f"Distribuição da variável alvo ({target_column}):")
    print(df_limpo[target_column].value_counts())
    
    # Criando uma variável binária para classificação (tem dengue ou não)
    # Neste exemplo, consideramos qualquer classificação (10, 11, 12) como positivo para dengue
    # Ajuste conforme necessário para seu caso específico
    print("\nCriando variável alvo binária (tem_dengue)...")
    df_limpo['tem_dengue'] = df_limpo[target_column].apply(lambda x: 1 if x in [10, 11, 12] else 0)
    print(df_limpo['tem_dengue'].value_counts())
    
    # Definindo a variável alvo final
    y = df_limpo['tem_dengue']
else:
    print(f"Atenção: Coluna {target_column} não encontrada no dataset.")
    print("Por favor, verifique o nome correto da variável alvo.")
    # Definindo uma variável alvo fictícia para continuar o exemplo
    y = pd.Series([0] * len(df_limpo))

# 4.2 Selecionando features para o modelo
#---------------------------------------
# Removendo colunas que não devem ser usadas como features
colunas_para_remover = [
    # Colunas de identificação
    'TP_NOT', 'ID_AGRAVO', 'SEM_NOT', 'NU_ANO',
    # Colunas de data (podem ser transformadas em features mais úteis)
    'DT_NOTIFIC', 'DT_SIN_PRI', 'DT_NASC',
    # Colunas com muitos valores ausentes ou pouco informativas
    'NDUPLIC_N', 'MIGRADO_W',
    # A variável alvo e suas derivadas
    target_column, 'tem_dengue'
]

# Removendo apenas as colunas que existem no dataframe
colunas_para_remover = [col for col in colunas_para_remover if col in df_limpo.columns]

# Criando o dataframe de features
X = df_limpo.drop(columns=colunas_para_remover, errors='ignore')

print(f"\nDataset de features criado com {X.shape[1]} colunas e {X.shape[0]} linhas.")

# 4.3 Identificando tipos de colunas para pré-processamento
#--------------------------------------------------------
# Separando colunas numéricas e categóricas
colunas_numericas = X.select_dtypes(include=['int64', 'float64']).columns.tolist()
colunas_categoricas = X.select_dtypes(include=['object', 'category']).columns.tolist()

print(f"\nColunas numéricas ({len(colunas_numericas)}): {colunas_numericas[:5]}...")
print(f"Colunas categóricas ({len(colunas_categoricas)}): {colunas_categoricas[:5]}...")

# 4.4 Feature Engineering - Criando novas features
#------------------------------------------------
print("\n--- Criando novas features ---")

# Exemplo 1: Criando features a partir de datas (se disponíveis)
if 'DT_NOTIFIC' in df_limpo.columns and 'DT_SIN_PRI' in df_limpo.columns:
    # Convertendo para datetime se ainda não for
    df_limpo['DT_NOTIFIC'] = pd.to_datetime(df_limpo['DT_NOTIFIC'], errors='coerce')
    df_limpo['DT_SIN_PRI'] = pd.to_datetime(df_limpo['DT_SIN_PRI'], errors='coerce')
    
    # Calculando o tempo entre primeiros sintomas e notificação (em dias)
    df_limpo['tempo_ate_notificacao'] = (df_limpo['DT_NOTIFIC'] - df_limpo['DT_SIN_PRI']).dt.days
    
    # Adicionando à lista de features numéricas
    if 'tempo_ate_notificacao' not in colunas_numericas:
        colunas_numericas.append('tempo_ate_notificacao')
        X['tempo_ate_notificacao'] = df_limpo['tempo_ate_notificacao']
    
    print("Feature 'tempo_ate_notificacao' criada com sucesso.")

# Exemplo 2: Criando um score de sintomas (contagem de sintomas presentes)
sintomas = ['FEBRE', 'MIALGIA', 'CEFALEIA', 'EXANTEMA', 'VOMITO', 'NAUSEA', 'DOR_COSTAS', 
           'CONJUNTVIT', 'ARTRITE', 'ARTRALGIA', 'PETEQUIA_N', 'LEUCOPENIA', 'LACO', 'DOR_RETRO']

# Filtrando apenas os sintomas presentes no dataset
sintomas_presentes = [s for s in sintomas if s in df_limpo.columns]

if sintomas_presentes:
    # Criando um score que conta quantos sintomas o paciente apresenta
    # Assumindo que valor 1 = presença do sintoma
    df_limpo['score_sintomas'] = df_limpo[sintomas_presentes].apply(
        lambda row: sum(1 for val in row if val == 1), axis=1
    )
    
    # Adicionando à lista de features numéricas
    if 'score_sintomas' not in colunas_numericas:
        colunas_numericas.append('score_sintomas')
        X['score_sintomas'] = df_limpo['score_sintomas']
    
    print("Feature 'score_sintomas' criada com sucesso.")

# Exemplo 3: Criando features de comorbidades
comorbidades = ['DIABETES', 'HEMATOLOG', 'HEPATOPAT', 'RENAL', 'HIPERTENSA', 
               'ACIDO_PEPT', 'AUTO_IMUNE']

# Filtrando apenas as comorbidades presentes no dataset
comorbidades_presentes = [c for c in comorbidades if c in df_limpo.columns]

if comorbidades_presentes:
    # Criando um score que conta quantas comorbidades o paciente apresenta
    df_limpo['score_comorbidades'] = df_limpo[comorbidades_presentes].apply(
        lambda row: sum(1 for val in row if val == 1), axis=1
    )
    
    # Adicionando à lista de features numéricas
    if 'score_comorbidades' not in colunas_numericas:
        colunas_numericas.append('score_comorbidades')
        X['score_comorbidades'] = df_limpo['score_comorbidades']
    
    print("Feature 'score_comorbidades' criada com sucesso.")

# 4.5 Configurando o pipeline de pré-processamento
#------------------------------------------------
print("\n--- Configurando pipeline de pré-processamento ---")

# Atualizando X com as novas features
X = X[colunas_numericas + colunas_categoricas]

# Pipeline para features numéricas
numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),  # Preenche valores ausentes com a mediana
    ('scaler', StandardScaler())  # Padroniza os dados (média 0, desvio padrão 1)
])

# Pipeline para features categóricas
categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),  # Preenche valores ausentes com a moda
    ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))  # Converte para one-hot encoding
])

# Combinando os pipelines
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, colunas_numericas),
        ('cat', categorical_transformer, colunas_categoricas)
    ])

print("Pipeline de pré-processamento configurado com sucesso.")
print(f"- Transformador numérico aplicado a {len(colunas_numericas)} colunas")
print(f"- Transformador categórico aplicado a {len(colunas_categoricas)} colunas")

# 4.6 Aplicando o pré-processamento
#---------------------------------
print("\n--- Aplicando pré-processamento aos dados ---")

# Aplicando o preprocessador aos dados
X_preprocessed = preprocessor.fit_transform(X)

print(f"Dados pré-processados: {X_preprocessed.shape}")

# Obtendo os nomes das colunas após one-hot encoding
if len(colunas_categoricas) > 0:
    # Obtendo os nomes das colunas categóricas após one-hot encoding
    cat_encoder = preprocessor.named_transformers_['cat'].named_steps['onehot']
    cat_cols = cat_encoder.get_feature_names_out(colunas_categoricas)
    
    # Combinando com os nomes das colunas numéricas
    feature_names = list(colunas_numericas) + list(cat_cols)
    print(f"Total de features após one-hot encoding: {len(feature_names)}")
else:
    feature_names = colunas_numericas
    print(f"Total de features (apenas numéricas): {len(feature_names)}")

# 4.7 Salvando os dados pré-processados para a próxima etapa
#----------------------------------------------------------
# Convertendo para DataFrame para melhor visualização
if len(feature_names) == X_preprocessed.shape[1]:
    X_preprocessed_df = pd.DataFrame(X_preprocessed, columns=feature_names)
    print("\nPrimeiras 5 linhas dos dados pré-processados:")
    print(X_preprocessed_df.head())
else:
    X_preprocessed_df = pd.DataFrame(X_preprocessed)
    print("\nPrimeiras 5 linhas dos dados pré-processados (sem nomes de colunas):")
    print(X_preprocessed_df.head())

print("\nFeature engineering e pré-processamento concluídos com sucesso!")

# 5. SELEÇÃO DE FEATURES RELEVANTES PARA O MODELO
#------------------------------------------------
print("\n" + "="*80)
print("5. SELEÇÃO DE FEATURES RELEVANTES PARA O MODELO")
print("="*80)

print("Iniciando seleção de features relevantes para o modelo...")

# Verificando se temos os nomes das features
try:
    # Se os dados foram convertidos para DataFrame com nomes de colunas
    feature_names = X_preprocessed_df.columns.tolist()
    print(f"Nomes das features disponíveis: {len(feature_names)} features")
except:
    # Caso contrário, criamos nomes genéricos
    feature_names = [f'feature_{i}' for i in range(X_preprocessed.shape[1])]
    print(f"Nomes genéricos criados para {len(feature_names)} features")

# 5.1 Análise de correlação com a variável alvo
#---------------------------------------------
print("\n--- Análise de correlação com a variável alvo ---")

# Criando um DataFrame temporário para análise de correlação
X_temp = pd.DataFrame(X_preprocessed, columns=feature_names)
X_temp['target'] = y.values

# Calculando correlação entre features e variável alvo
correlacoes = X_temp.corr()['target'].sort_values(ascending=False)

print("Top 10 features com maior correlação positiva com a variável alvo:")
print(correlacoes.head(11).drop('target', errors='ignore'))

print("\nTop 10 features com maior correlação negativa com a variável alvo:")
print(correlacoes.tail(10))

# Visualizando as correlações
plt.figure(figsize=(12, 8))
correlacoes_top = pd.concat([correlacoes.head(15).drop('target', errors='ignore'), 
                            correlacoes.tail(5)])
sns.barplot(x=correlacoes_top.values, y=correlacoes_top.index)
plt.title('Correlação das Features com a Variável Alvo', fontsize=14)
plt.xlabel('Coeficiente de Correlação')
plt.ylabel('Features')
plt.axvline(x=0, color='r', linestyle='--')
plt.tight_layout()
plt.show()

# 5.2 Seleção de features usando SelectKBest com ANOVA F-value
#------------------------------------------------------------
print("\n--- Seleção de features usando SelectKBest (ANOVA F-value) ---")

# Definindo o número de features a selecionar (ajuste conforme necessário)
k = min(20, X_preprocessed.shape[1])  # No máximo 20 features ou o total disponível

# Aplicando SelectKBest com ANOVA F-value
selector_f = SelectKBest(score_func=f_classif, k=k)
X_selected_f = selector_f.fit_transform(X_preprocessed, y)

# Obtendo os scores e índices das features selecionadas
scores_f = selector_f.scores_
indices_f = np.argsort(scores_f)[::-1]

print(f"Número de features selecionadas: {X_selected_f.shape[1]}")

# Visualizando as features mais importantes segundo ANOVA F-value
plt.figure(figsize=(12, 8))
top_indices_f = indices_f[:k]
top_scores_f = scores_f[top_indices_f]
top_names_f = [feature_names[i] if i < len(feature_names) else f'feature_{i}' for i in top_indices_f]

sns.barplot(x=top_scores_f, y=top_names_f)
plt.title('Top Features Selecionadas (ANOVA F-value)', fontsize=14)
plt.xlabel('F-value Score')
plt.ylabel('Features')
plt.tight_layout()
plt.show()

# 5.3 Seleção de features usando Random Forest Importance
#------------------------------------------------------
print("\n--- Seleção de features usando Random Forest Importance ---")

# Treinando um Random Forest para obter importância das features
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_preprocessed, y)

# Obtendo a importância das features
importances = rf.feature_importances_
indices = np.argsort(importances)[::-1]

print("Top 10 features mais importantes segundo Random Forest:")
for i in range(min(10, X_preprocessed.shape[1])):
    feature_idx = indices[i]
    feature_name = feature_names[feature_idx] if feature_idx < len(feature_names) else f'feature_{feature_idx}'
    print(f"{i+1}. {feature_name}: {importances[feature_idx]:.4f}")

# Visualizando a importância das features
plt.figure(figsize=(12, 8))
top_k = min(20, X_preprocessed.shape[1])
top_indices = indices[:top_k]
top_importances = importances[top_indices]
top_names = [feature_names[i] if i < len(feature_names) else f'feature_{i}' for i in top_indices]

sns.barplot(x=top_importances, y=top_names)
plt.title('Importância das Features (Random Forest)', fontsize=14)
plt.xlabel('Importância')
plt.ylabel('Features')
plt.tight_layout()
plt.show()

# 5.4 Selecionando o conjunto final de features
#---------------------------------------------
print("\n--- Selecionando o conjunto final de features ---")

# Usando as top N features do Random Forest
n_final = min(20, X_preprocessed.shape[1])  # Ajuste conforme necessário
final_features_rf = [feature_names[i] if i < len(feature_names) else f'feature_{i}' for i in indices[:n_final]]

print(f"Número de features no conjunto final (Random Forest top {n_final}): {len(final_features_rf)}")

# Criando o conjunto final de features para o modelo
X_final = X_preprocessed[:, indices[:n_final]]
final_feature_names = [feature_names[i] if i < len(feature_names) else f'feature_{i}' for i in indices[:n_final]]

print("\nFeatures finais selecionadas para o modelo:")
for i, feature in enumerate(final_feature_names):
    print(f"{i+1}. {feature}")

print("\nSeleção de features concluída com sucesso!")

# 6. TREINO E TESTE DE MODELOS DE MACHINE LEARNING
#-------------------------------------------------
print("\n" + "="*80)
print("6. TREINO E TESTE DE MODELOS DE MACHINE LEARNING")
print("="*80)

print("Iniciando treino e teste de modelos de machine learning...")

# 6.1 Divisão dos dados em conjuntos de treino e teste
#----------------------------------------------------
print("\n--- Dividindo os dados em conjuntos de treino e teste ---")

# Dividindo os dados (80% treino, 20% teste)
X_train, X_test, y_train, y_test = train_test_split(
    X_final, y, test_size=0.2, random_state=42, stratify=y
)

print(f"Conjunto de treino: {X_train.shape[0]} amostras")
print(f"Conjunto de teste: {X_test.shape[0]} amostras")

# Verificando a distribuição da variável alvo nos conjuntos
print("\nDistribuição da variável alvo no conjunto de treino:")
print(pd.Series(y_train).value_counts(normalize=True) * 100)

print("\nDistribuição da variável alvo no conjunto de teste:")
print(pd.Series(y_test).value_counts(normalize=True) * 100)

# 6.2 Definindo os modelos a serem testados
#-----------------------------------------
print("\n--- Definindo os modelos a serem testados ---")

# Criando um dicionário com os modelos
models = {
    'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
    'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
    'Gradient Boosting': GradientBoostingClassifier(n_estimators=100, random_state=42),
    'SVM': SVC(probability=True, random_state=42),
    'KNN': KNeighborsClassifier(n_neighbors=5)
}

print(f"Modelos a serem testados: {', '.join(models.keys())}")

# 6.3 Treinando e avaliando os modelos
#------------------------------------
print("\n--- Treinando e avaliando os modelos ---")

# Dicionários para armazenar resultados
resultados = {}
tempos_treino = {}
tempos_predicao = {}

# Treinando e avaliando cada modelo
for nome, modelo in models.items():
    print(f"\nTreinando modelo: {nome}")
    
    # Medindo o tempo de treino
    inicio_treino = time.time()
    modelo.fit(X_train, y_train)
    fim_treino = time.time()
    tempo_treino = fim_treino - inicio_treino
    tempos_treino[nome] = tempo_treino
    
    # Medindo o tempo de predição
    inicio_predicao = time.time()
    y_pred = modelo.predict(X_test)
    fim_predicao = time.time()
    tempo_predicao = fim_predicao - inicio_predicao
    tempos_predicao[nome] = tempo_predicao
    
    # Calculando métricas
    acuracia = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred, output_dict=True)
    
    # Armazenando resultados
    resultados[nome] = {
        'acuracia': acuracia,
        'report': report,
        'modelo': modelo,
        'predicoes': y_pred
    }
    
    print(f"Acurácia: {acuracia:.4f}")
    print(f"Tempo de treino: {tempo_treino:.4f} segundos")
    print(f"Tempo de predição: {tempo_predicao:.4f} segundos")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

# 6.4 Visualizando as matrizes de confusão
#----------------------------------------
print("\n--- Visualizando as matrizes de confusão ---")

# Criando uma figura para as matrizes de confusão
plt.figure(figsize=(15, 10))

for i, (nome, resultado) in enumerate(resultados.items(), 1):
    plt.subplot(2, 3, i)
    cm = confusion_matrix(y_test, resultado['predicoes'])
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False)
    plt.title(f'Matriz de Confusão - {nome}')
    plt.xlabel('Predito')
    plt.ylabel('Real')
    plt.tight_layout()

plt.suptitle('Matrizes de Confusão para Diferentes Modelos', fontsize=16)
plt.subplots_adjust(top=0.9)
plt.show()

# 6.5 Curvas ROC para comparação dos modelos
#------------------------------------------
print("\n--- Gerando curvas ROC para comparação dos modelos ---")

plt.figure(figsize=(10, 8))

for nome, modelo in models.items():
    # Obtendo probabilidades para a classe positiva
    try:
        y_proba = modelo.predict_proba(X_test)[:, 1]
        
        # Calculando a curva ROC
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        roc_auc = auc(fpr, tpr)
        
        # Plotando a curva ROC
        plt.plot(fpr, tpr, label=f'{nome} (AUC = {roc_auc:.3f})')
    except:
        print(f"Não foi possível gerar a curva ROC para o modelo {nome}")

# Adicionando a linha diagonal de referência
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel('Taxa de Falsos Positivos')
plt.ylabel('Taxa de Verdadeiros Positivos')
plt.title('Curvas ROC para Diferentes Modelos')
plt.legend(loc='lower right')
plt.grid(True)
plt.show()

# 6.6 Validação cruzada para avaliação mais robusta
#-------------------------------------------------
print("\n--- Realizando validação cruzada para avaliação mais robusta ---")

# Número de folds para validação cruzada
n_folds = 5

# Dicionário para armazenar resultados da validação cruzada
cv_results = {}

for nome, modelo in models.items():
    print(f"\nValidação cruzada para {nome}:")
    
    # Realizando validação cruzada
    cv_scores = cross_val_score(modelo, X_final, y, cv=n_folds, scoring='accuracy')
    
    # Armazenando resultados
    cv_results[nome] = {
        'scores': cv_scores,
        'mean': cv_scores.mean(),
        'std': cv_scores.std()
    }
    
    print(f"Scores: {cv_scores}")
    print(f"Acurácia média: {cv_scores.mean():.4f} (±{cv_scores.std():.4f})")

# Visualizando os resultados da validação cruzada
plt.figure(figsize=(12, 6))
cv_means = [cv_results[nome]['mean'] for nome in models.keys()]
cv_stds = [cv_results[nome]['std'] for nome in models.keys()]
model_names = list(models.keys())

# Ordenando por desempenho
sorted_indices = np.argsort(cv_means)[::-1]
cv_means = [cv_means[i] for i in sorted_indices]
cv_stds = [cv_stds[i] for i in sorted_indices]
model_names = [model_names[i] for i in sorted_indices]

# Plotando os resultados
plt.bar(model_names, cv_means, yerr=cv_stds, capsize=10, alpha=0.7)
plt.title('Acurácia Média na Validação Cruzada (5-fold)', fontsize=14)
plt.ylabel('Acurácia')
plt.ylim(0.5, 1.0)  # Ajuste conforme necessário
plt.xticks(rotation=45, ha='right')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()

# 7. AVALIAÇÃO E COMPARAÇÃO DE ACURÁCIA DOS MODELOS
#--------------------------------------------------
print("\n" + "="*80)
print("7. AVALIAÇÃO E COMPARAÇÃO DE ACURÁCIA DOS MODELOS")
print("="*80)

print("Iniciando avaliação e comparação detalhada dos modelos...")

# 7.1 Compilando métricas de desempenho para todos os modelos
#-----------------------------------------------------------
print("\n--- Compilando métricas de desempenho para todos os modelos ---")

# Criando um DataFrame para comparar os modelos
metricas = ['Acurácia', 'Precisão', 'Recall', 'F1-Score', 'AUC-ROC', 'Tempo Treino (s)', 'Tempo Predição (s)']
comparacao_df = pd.DataFrame(index=resultados.keys(), columns=metricas)

# Preenchendo o DataFrame com as métricas
for nome, resultado in resultados.items():
    modelo = resultado['modelo']
    y_pred = resultado['predicoes']
    
    # Calculando métricas básicas
    comparacao_df.loc[nome, 'Acurácia'] = accuracy_score(y_test, y_pred)
    comparacao_df.loc[nome, 'Precisão'] = precision_score(y_test, y_pred, average='weighted')
    comparacao_df.loc[nome, 'Recall'] = recall_score(y_test, y_pred, average='weighted')
    comparacao_df.loc[nome, 'F1-Score'] = f1_score(y_test, y_pred, average='weighted')
    
    # Calculando AUC-ROC (se possível)
    try:
        y_proba = modelo.predict_proba(X_test)[:, 1]
        comparacao_df.loc[nome, 'AUC-ROC'] = roc_auc_score(y_test, y_proba)
    except:
        comparacao_df.loc[nome, 'AUC-ROC'] = np.nan
    
    # Adicionando tempos de execução
    comparacao_df.loc[nome, 'Tempo Treino (s)'] = tempos_treino[nome]
    comparacao_df.loc[nome, 'Tempo Predição (s)'] = tempos_predicao[nome]

# Ordenando o DataFrame pela acurácia (decrescente)
comparacao_df = comparacao_df.sort_values('Acurácia', ascending=False)

# Exibindo o DataFrame de comparação
print("\nComparação de desempenho dos modelos:")
print(comparacao_df)

# 7.2 Adicionando resultados da validação cruzada
#-----------------------------------------------
print("\n--- Adicionando resultados da validação cruzada ---")

# Criando um DataFrame para os resultados da validação cruzada
cv_df = pd.DataFrame(index=cv_results.keys(), columns=['CV Média', 'CV Desvio Padrão'])

for nome, resultado in cv_results.items():
    cv_df.loc[nome, 'CV Média'] = resultado['mean']
    cv_df.loc[nome, 'CV Desvio Padrão'] = resultado['std']

# Ordenando o DataFrame pela média da validação cruzada (decrescente)
cv_df = cv_df.sort_values('CV Média', ascending=False)

# Exibindo o DataFrame de validação cruzada
print("\nResultados da validação cruzada:")
print(cv_df)

# 7.3 Visualizando a comparação de métricas
#-----------------------------------------
print("\n--- Visualizando a comparação de métricas ---")

# Preparando os dados para visualização
metricas_viz = ['Acurácia', 'Precisão', 'Recall', 'F1-Score']
comparacao_viz = comparacao_df[metricas_viz].copy()

# Criando um gráfico de barras para comparar as métricas
plt.figure(figsize=(14, 8))
comparacao_viz.plot(kind='bar', figsize=(14, 8), ylim=(0.5, 1.0), width=0.8)
plt.title('Comparação de Métricas entre Modelos', fontsize=16)
plt.xlabel('Modelo', fontsize=14)
plt.ylabel('Valor da Métrica', fontsize=14)
plt.xticks(rotation=45, ha='right')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.legend(title='Métrica', fontsize=12)
plt.tight_layout()
plt.show()

# 7.4 Identificando o melhor modelo considerando múltiplos critérios
#-----------------------------------------------------------------
print("\n--- Identificando o melhor modelo considerando múltiplos critérios ---")

# Critérios para seleção do melhor modelo:
# 1. Acurácia na validação cruzada (robustez)
# 2. Acurácia no conjunto de teste
# 3. F1-Score (balanceamento entre precisão e recall)
# 4. Tempo de predição (eficiência)

# Normalizando as métricas para comparação justa
metricas_normalizadas = pd.DataFrame(index=resultados.keys())
metricas_normalizadas['Acurácia CV'] = cv_df['CV Média'] / cv_df['CV Média'].max()
metricas_normalizadas['Acurácia Teste'] = comparacao_df['Acurácia'] / comparacao_df['Acurácia'].max()
metricas_normalizadas['F1-Score'] = comparacao_df['F1-Score'] / comparacao_df['F1-Score'].max()
metricas_normalizadas['Eficiência'] = 1 - (comparacao_df['Tempo Predição (s)'] / comparacao_df['Tempo Predição (s)'].max())

# Calculando uma pontuação ponderada
pesos = {'Acurácia CV': 0.4, 'Acurácia Teste': 0.3, 'F1-Score': 0.2, 'Eficiência': 0.1}
metricas_normalizadas['Pontuação'] = sum(metricas_normalizadas[metrica] * peso for metrica, peso in pesos.items())

# Ordenando pela pontuação
metricas_normalizadas = metricas_normalizadas.sort_values('Pontuação', ascending=False)

# Exibindo o DataFrame de pontuação
print("\nPontuação dos modelos considerando múltiplos critérios:")
print(metricas_normalizadas)

# Identificando o melhor modelo
melhor_modelo_nome = metricas_normalizadas.index[0]
melhor_modelo = resultados[melhor_modelo_nome]['modelo']

print(f"\nMelhor modelo considerando múltiplos critérios: {melhor_modelo_nome}")
print(f"Acurácia no teste: {comparacao_df.loc[melhor_modelo_nome, 'Acurácia']:.4f}")
print(f"Acurácia na validação cruzada: {cv_df.loc[melhor_modelo_nome, 'CV Média']:.4f}")
print(f"F1-Score: {comparacao_df.loc[melhor_modelo_nome, 'F1-Score']:.4f}")
print(f"Tempo de predição: {comparacao_df.loc[melhor_modelo_nome, 'Tempo Predição (s)']:.4f} segundos")

# 7.5 Recomendações finais
#------------------------
print("\n--- Recomendações finais ---")

print(f"""
Recomendações baseadas na análise dos modelos:

1. Melhor modelo geral: {melhor_modelo_nome}
   - Este modelo apresentou o melhor equilíbrio entre acurácia, robustez e eficiência.
   - Acurácia no teste: {comparacao_df.loc[melhor_modelo_nome, 'Acurácia']:.4f}
   - Acurácia na validação cruzada: {cv_df.loc[melhor_modelo_nome, 'CV Média']:.4f}

2. Modelo mais rápido: {comparacao_df['Tempo Predição (s)'].idxmin()}
   - Se a velocidade de predição for crítica, este modelo é o mais eficiente.
   - Tempo de predição: {comparacao_df['Tempo Predição (s)'].min():.4f} segundos
   - Acurácia no teste: {comparacao_df.loc[comparacao_df['Tempo Predição (s)'].idxmin(), 'Acurácia']:.4f}

3. Modelo mais preciso no teste: {comparacao_df['Acurácia'].idxmax()}
   - Se a prioridade for maximizar a acurácia no conjunto de teste.
   - Acurácia no teste: {comparacao_df['Acurácia'].max():.4f}
   - Tempo de predição: {comparacao_df.loc[comparacao_df['Acurácia'].idxmax(), 'Tempo Predição (s)']:.4f} segundos

4. Modelo mais robusto (validação cruzada): {cv_df['CV Média'].idxmax()}
   - Se a prioridade for a robustez e generalização do modelo.
   - Acurácia na validação cruzada: {cv_df['CV Média'].max():.4f}
   - Acurácia no teste: {comparacao_df.loc[cv_df['CV Média'].idxmax(), 'Acurácia']:.4f}
""")

print("\n" + "="*80)
print("ANÁLISE EXPLORATÓRIA E MACHINE LEARNING PARA DETECÇÃO DE DENGUE - CONCLUÍDO")
print("="*80)
print("""
Resumo do pipeline executado:
1. Carregamento e exploração inicial dos dados
2. Limpeza e tratamento de valores ausentes
3. Visualização exploratória dos dados
4. Feature engineering e pré-processamento
5. Seleção de features relevantes
6. Treino e teste de modelos de machine learning
7. Avaliação e comparação de acurácia dos modelos

Próximos passos sugeridos:
- Ajustar hiperparâmetros do melhor modelo para melhorar ainda mais o desempenho
- Explorar técnicas de balanceamento de classes se o dataset estiver desbalanceado
- Implementar o modelo em um ambiente de produção para uso prático
- Monitorar o desempenho do modelo com novos dados ao longo do tempo
""")
